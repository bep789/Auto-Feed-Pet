#include <WiFi.h>
#include <ESP32Servo.h>
#include <time.h>

// =============================
// WiFi หรือ จากมือถือ
// =============================
const char* ssid = "ชื่อ WiFi";
const char* password = "รหัส WiFi";

// =============================
// Servo
// =============================
Servo myServo;

const int SERVO_PIN = 18; //ขาที่จะให้ออกตามที่บอร์ดแสดง

// ตำแหน่ง Servo
const int CLOSE_ANGLE = 0; //มุมปิดที่ให้อาหาร
const int OPEN_ANGLE  = 90; //มุมเปิดอาหาร มากสุด 90 ยิ่งเยอะยิ่งเทมาก

// =============================
// ตั้งเวลา 3 ครั้ง
// =============================

// เช้า
const int MORNING_HOUR = 7;  //เวลาเช้าชั่วโมงที่ตั้ง
const int MORNING_MINUTE = 0;

// เที่ยง
const int NOON_HOUR = 12; //เวลาเที่ยงชั่วโมงที่ตั้ง
const int NOON_MINUTE = 0;

// เย็น
const int EVENING_HOUR = 18; //เวลาเย็นชั่วโมงที่ตั้ง
const int EVENING_MINUTE = 0;

// =============================
// ป้องกันการทำงานซ้ำ
// =============================

int lastMorningDay = -1;
int lastNoonDay = -1;
int lastEveningDay = -1;


// =============================
// ฟังก์ชันเปิด Servo
// =============================

void activateServo() {

  Serial.println("Servo เปิด");

  myServo.write(OPEN_ANGLE);

  delay(1000);   // เปิดค้าง 1 วินาที      **** 1000 = 1 วิ ยิ่งมากยิ่งเปิดค้างนาน

  myServo.write(CLOSE_ANGLE);

  Serial.println("Servo ปิด");
}


void setup() {

  Serial.begin(115200);

  myServo.attach(SERVO_PIN);

  myServo.write(CLOSE_ANGLE);


  WiFi.begin(ssid, password);

  Serial.print("กำลังเชื่อมต่อ WiFi");

  while (WiFi.status() != WL_CONNECTED) {

    delay(500);

    Serial.print(".");
  }

  Serial.println();
  Serial.println("WiFi Connected");

  // เวลาไทย UTC+7

  configTime(
    7 * 3600,
    0,
    "pool.ntp.org",
    "time.nist.gov"
  );

  Serial.println("กำลังรับเวลาจาก Internet...");

  struct tm timeinfo;

  while (!getLocalTime(&timeinfo)) {

    Serial.println("รอเวลา...");
    delay(1000);
  }

  Serial.println("ได้รับเวลาแล้ว");
}


void loop() {

  struct tm timeinfo;

  if (!getLocalTime(&timeinfo)) {

    Serial.println("อ่านเวลาไม่ได้");

    delay(1000);

    return;
  }

  int hour = timeinfo.tm_hour;
  int minute = timeinfo.tm_min;
  int second = timeinfo.tm_sec;

  int day = timeinfo.tm_yday;


  Serial.printf(
    "เวลา %02d:%02d:%02d\n",
    hour,
    minute,
    second
  );



  // เช้า


  if (
    hour == MORNING_HOUR &&
    minute == MORNING_MINUTE &&
    lastMorningDay != day
  ) {

    activateServo();

    lastMorningDay = day;
  }



  // เที่ยง


  if (
    hour == NOON_HOUR &&
    minute == NOON_MINUTE &&
    lastNoonDay != day
  ) {

    activateServo();

    lastNoonDay = day;
  }



  // เย็น


  if (
    hour == EVENING_HOUR &&
    minute == EVENING_MINUTE &&
    lastEveningDay != day
  ) {

    activateServo();

    lastEveningDay = day;
  }


  delay(1000);
}